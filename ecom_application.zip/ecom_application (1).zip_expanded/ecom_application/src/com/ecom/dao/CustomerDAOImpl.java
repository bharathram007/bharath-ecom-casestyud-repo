package com.ecom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ecom.entity.Customer;
import com.ecom.exception.CustomerNotFoundException;
import com.ecom.util.DBUtil;

public class CustomerDAOImpl implements ICustomerDAO {

	@Override
	public boolean createCustomer(Customer customer) throws ClassNotFoundException, SQLException {
		try (Connection connection = DBUtil.createConnection()) {
			String sql = "INSERT INTO customers (name, email, password) VALUES (?, ?, ?)";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setString(1, customer.getName());
				statement.setString(2, customer.getEmail());
				statement.setString(3, customer.getPassword());

				int rowsInserted = statement.executeUpdate();
				return rowsInserted > 0;
			}
		}
	}

	@Override
	public boolean deleteCustomer(int customerId)
			throws ClassNotFoundException, SQLException, CustomerNotFoundException {
		try (Connection connection = DBUtil.createConnection()) {
			String sql = "DELETE FROM customers WHERE customer_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setInt(1, customerId);

				int rowsDeleted = statement.executeUpdate();
				if (rowsDeleted == 0) {
					throw new CustomerNotFoundException("Customer not found with ID: " + customerId);
				}

				return true;
			}
		}
	}

	@Override
	public Customer viewCustomer(int customerId)
			throws ClassNotFoundException, SQLException, CustomerNotFoundException {
		try (Connection connection = DBUtil.createConnection()) {
			String sql = "SELECT * FROM customers WHERE customer_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setInt(1, customerId);

				try (ResultSet resultSet = statement.executeQuery()) {
					if (resultSet.next()) {
						// Map the result set to a Customer object
						Customer customer = new Customer();
						customer.setCustomerId(resultSet.getInt("customer_id"));
						customer.setName(resultSet.getString("name"));
						customer.setEmail(resultSet.getString("email"));
						customer.setPassword(resultSet.getString("password"));

						return customer;
					} else {
						throw new CustomerNotFoundException("Customer not found with ID: " + customerId);
					}
				}
			}
		}
	}

	@Override
	public List<Customer> viewCustomers() throws ClassNotFoundException, SQLException, CustomerNotFoundException {
		try (Connection connection = DBUtil.createConnection()) {
			String sql = "SELECT * FROM customers";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {

				try (ResultSet resultSet = statement.executeQuery()) {
					List<Customer> customers = new ArrayList<>();

					while (resultSet.next()) {
						// Map each row to a Customer object and add to the list
						Customer customer = new Customer();
						customer.setCustomerId(resultSet.getInt("customer_id"));
						customer.setName(resultSet.getString("name"));
						customer.setEmail(resultSet.getString("email"));
						customer.setPassword(resultSet.getString("password"));

						customers.add(customer);
					}

					if (customers.isEmpty()) {
						throw new CustomerNotFoundException("No customers found.");
					}

					return customers;
				}
			}
		}
	}
}
