package com.ecom.dao;

import java.sql.SQLException;
import java.util.List;

import com.ecom.entity.Product;
import com.ecom.exception.ProductNotFoundException;

public interface IProductDAO {
	public boolean createProduct(Product product) throws ClassNotFoundException, SQLException;

	public boolean deleteProduct(int productId) throws ClassNotFoundException, SQLException, ProductNotFoundException;

	public Product viewProduct(int productId) throws ClassNotFoundException, SQLException, ProductNotFoundException;

	public List<Product> viewProducts() throws ClassNotFoundException, SQLException, ProductNotFoundException;
}
