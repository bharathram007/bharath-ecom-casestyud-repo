package com.ecom.dao;

import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ecom.entity.Customer;
import com.ecom.exception.CustomerNotFoundException;

public class CustomerDAOImplTest {

	private ICustomerDAO customerDAO;

	@Before
	public void setUp() throws Exception {
		customerDAO = new CustomerDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		customerDAO = null;
	}

	@Test
	public final void testCreateCustomer() {
		boolean result = false;
		Customer customer = new Customer("ABC", "abc@gmail.com", "abc123");
		try {
			result = customerDAO.createCustomer(customer);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}
		assertTrue("Customer creation should be successful",result);
	}

	@Test
	public final void testDeleteCustomer() {
		boolean result = false;
		int customerId = 8;
		try {
			result = customerDAO.deleteCustomer(customerId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (CustomerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue("Customer deletion should be successful",result);
	}

	@Test
	public final void testViewCustomer() {
		Customer customer = null;
		int customerId = 3;
		try {
			customer = customerDAO.viewCustomer(customerId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (CustomerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue("Customer should not be null",customer != null);

	}

	@Test
	public final void testViewCustomers() {
		List<Customer> customerList = null;

		try {
			customerList = customerDAO.viewCustomers();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (CustomerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue("Customer list should not be null",customerList != null);

	}

}
