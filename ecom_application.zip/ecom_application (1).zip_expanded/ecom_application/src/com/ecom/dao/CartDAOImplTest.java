package com.ecom.dao;

import static org.junit.Assert.assertTrue;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;

public class CartDAOImplTest {

	private ICartDAO cartDAO;

	@Before
	public void setUp() throws Exception {
		cartDAO = new CartDAOImpl();

	}

	@After
	public void tearDown() throws Exception {
		cartDAO = null;

	}

	@Test
	public final void testtAddToCart() {
		Customer customer = new Customer("Jack", "jack@gmail.com", "jack123");

		Product product = new Product("Smartphone", 800.00, "Latest smartphone model", 10);

		try {

			cartDAO.addToCart(customer, product, 2); 
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username, or password is wrong or duplicate record");
//			se.printStackTrace();
		}
		assertTrue(true);
	}

	@Test
	public final void testRemoveFromCart() {
		Customer customer = new Customer("John", "john@example.com", "password");
		Product product = new Product("Smartphone", 800.00, "Latest smartphone model", 10);

		try {
			cartDAO.addToCart(customer, product, 2);

			cartDAO.removeFromCart(customer, product);

		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username, or password is wrong or duplicate record");
//			se.printStackTrace();
		}
		assertTrue(true);

	}
}
