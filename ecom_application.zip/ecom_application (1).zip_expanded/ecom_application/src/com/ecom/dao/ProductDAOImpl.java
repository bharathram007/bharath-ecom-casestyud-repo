package com.ecom.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ecom.entity.Product;
import com.ecom.exception.ProductNotFoundException;
import com.ecom.util.DBUtil;

public class ProductDAOImpl implements IProductDAO {

	@Override
	public boolean createProduct(Product product) throws ClassNotFoundException, SQLException {
		try (Connection connection = DBUtil.createConnection()) {
			String sql = "INSERT INTO products (name, price, description, stock_quantity) VALUES (?, ?, ?, ?)";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setString(1, product.getName());
				statement.setDouble(2, product.getPrice());
				statement.setString(3, product.getDescription());
				statement.setInt(4, product.getStockQuantity());

				int rowsInserted = statement.executeUpdate();
				return rowsInserted > 0;
			}
		}
	}

	@Override
	public boolean deleteProduct(int productId) throws ClassNotFoundException, SQLException, ProductNotFoundException {
		try (Connection connection = DBUtil.createConnection()) {
			String sql = "DELETE FROM products WHERE product_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setInt(1, productId);

				int rowsDeleted = statement.executeUpdate();
				if (rowsDeleted == 0) {
					throw new ProductNotFoundException("Product not found with ID: " + productId);
				}

				return true;
			}
		}
	}

	@Override
	public Product viewProduct(int productId) throws ClassNotFoundException, SQLException, ProductNotFoundException {
		try (Connection connection = DBUtil.createConnection()) {
			String sql = "SELECT * FROM products WHERE product_id = ?";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setInt(1, productId);

				try (ResultSet resultSet = statement.executeQuery()) {
					if (resultSet.next()) {
						// Map the result set to a Product object
						Product product = new Product();
						product.setProductId(resultSet.getInt("product_id"));
						product.setName(resultSet.getString("name"));
						product.setPrice(resultSet.getDouble("price"));
						product.setDescription(resultSet.getString("description"));
						product.setStockQuantity(resultSet.getInt("stock_quantity"));

						return product;
					} else {
						throw new ProductNotFoundException("Product not found with ID: " + productId);
					}
				}
			}
		}
	}

	@Override
	public List<Product> viewProducts() throws ClassNotFoundException, SQLException, ProductNotFoundException {
		try (Connection connection = DBUtil.createConnection()) {
			String sql = "SELECT * FROM products";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {

				try (ResultSet resultSet = statement.executeQuery()) {
					List<Product> products = new ArrayList<>();

					while (resultSet.next()) {
						Product product = new Product();
						product.setProductId(resultSet.getInt("product_id"));
						product.setName(resultSet.getString("name"));
						product.setPrice(resultSet.getDouble("price"));
						product.setDescription(resultSet.getString("description"));
						product.setStockQuantity(resultSet.getInt("stock_quantity"));

						products.add(product);
					}

					if (products.isEmpty()) {
						throw new ProductNotFoundException("No products found.");
					}

					return products;
				}
			}
		}
	}

}
