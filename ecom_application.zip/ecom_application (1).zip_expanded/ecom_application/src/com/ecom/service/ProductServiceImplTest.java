package com.ecom.service;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ecom.entity.Product;

public class ProductServiceImplTest {
	private IProductService productService;

	@Before
	public void setUp() throws Exception {
		productService = new ProductServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		productService = null;
	}

	@Test
	public final void testCreateProduct() {
		boolean result = false;
		Product product = new Product("AC", 6000.00, "Worlds no.1 AC", 5);
		result = productService.createProduct(product);
		assertTrue("Product creation should be successful", result);
	}

	@Test
	public final void testDeleteProduct() {
		boolean result = false;
		int productId = 8;
		result = productService.deleteProduct(productId);

		assertTrue("Product deletion should be successful", result);
	}

	@Test
	public final void testViewProduct() {
		Product product = null;
		int productId = 3;
		product = productService.viewProduct(productId);

		assertTrue("Product should not be null", product != null);
	}

	@Test
	public final void testViewProducts() {
		List<Product> productList = null;

		productList = productService.viewProducts();
		assertTrue("Product list should not be null", productList != null);
	}

}
